HENOF + AKATSUKI DASHBOARD INTEGRATION

This package adds the informational Akatsuki dashboard as a separate section:
https://extorsionista.github.io/HenOF/akatsuki/

UPLOAD:
1. Extract this ZIP.
2. Open your Extorsionista/HenOF repository on GitHub.
3. Upload the entire "akatsuki" folder into the repository root.
   Keep the folder name exactly: akatsuki
4. In the existing root index.html, add this link somewhere in the homepage
   navigation or hero action area:

   <a href="./akatsuki/">Akatsuki 14.02 Dashboard</a>

5. Commit the changes to the main branch.
6. Wait for GitHub Pages to publish, then open the /akatsuki/ URL above.

IMPORTANT:
The dashboard is informational only. Its clock and refresh indicator update
the website interface, not a PS4 console. It does not execute or automate the
experimental WebKit/kernel exploit chain. The supplied project README states
that the 14.02 build has not been tested on hardware and may freeze a console.
